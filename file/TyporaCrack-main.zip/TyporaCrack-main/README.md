# [Typora](https://typora.io/)

## 使用说明

- ### Windows

  - 在官网下载并安装 Typora
  - 下载并解压 Windows 版压缩包，将 `winmm.dll` 复制到安装目录下

- ### Mac

  - 下载并安装即可